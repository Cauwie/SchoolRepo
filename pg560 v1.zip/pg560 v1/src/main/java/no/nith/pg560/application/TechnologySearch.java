package no.nith.pg560.application;

public class TechnologySearch {

	public TechnologySearch() {
		
	
	}
}
