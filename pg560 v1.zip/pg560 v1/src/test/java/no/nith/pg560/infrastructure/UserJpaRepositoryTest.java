package no.nith.pg560.infrastructure;

import no.nith.pg560.common.CommonInfrastructureIT;
import org.junit.Test;

import static org.junit.Assert.*;

public class UserJpaRepositoryTest extends CommonInfrastructureIT {

//	@Test
//	public void testGetUser() {
//		UserJpaRepository userRepo = new UserJpaRepository(getEntityManager());
//		User userResult = userRepo.getUser("tonnyg");
//		assertEquals(userResult.getName(), "Tonny Gundersen");
//		assertEquals(userResult.getCity(), "Oslo");
//		assertEquals(userResult.getCountry(), "Norway");
//
//		userResult = userRepo.getUser("Finnes ikke");
//		assertNull(userResult);
//	}

}
